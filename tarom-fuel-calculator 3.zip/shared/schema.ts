import { pgTable, text, serial, numeric, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const fuelCalculations = pgTable("fuel_calculations", {
  id: serial("id").primaryKey(),
  aircraftType: text("aircraft_type").notNull(),
  registration: text("registration").notNull(),
  flightNumber: text("flight_number").notNull(),
  date: timestamp("date").notNull().defaultNow(),
  time: text("time").notNull(),
  fromLocation: text("from_location").notNull(),
  toLocation: text("to_location").notNull(),
  orderedBy: text("ordered_by").notNull(),
  checkedBy: text("checked_by").notNull(),
  performedBy: text("performed_by").notNull(),

  // Actual Fuel Quantity
  leftTank: numeric("left_tank").notNull(),
  centerTank: numeric("center_tank"),
  rightTank: numeric("right_tank").notNull(),

  // After Refueling (MLI/Drip sticks)
  leftTankAfter: numeric("left_tank_after").notNull(),
  centerTankAfter: numeric("center_tank_after"),
  rightTankAfter: numeric("right_tank_after").notNull(),

  // Calculations
  totalRequested: numeric("total_requested").notNull(), // Total (A)
  totalIndicators: numeric("total_indicators").notNull(), // Total (B)
  fobBeforeRefueling: numeric("fob_before_refueling").notNull(), // (C)
  requiredUplift: numeric("required_uplift").notNull(), // (D)
  density: numeric("density").notNull(), // (E)
  toUplift: numeric("to_uplift").notNull(), // (F)

  // Fuel Quantity Calculation
  upliftedLiters: numeric("uplifted_liters").notNull(), // (H)
  upliftQuantity: numeric("uplift_quantity").notNull(), // (J)
  rfob: numeric("rfob").notNull(), // (K)
  totalCfobAfterRefueling: numeric("total_cfob_after_refueling").notNull(), // (L)
  usedFuel: numeric("used_fuel").notNull(), // (M)
  cfobAfterRefueling: numeric("cfob_after_refueling").notNull(), // (N)
  totalIndicatedFob: numeric("total_indicated_fob").notNull(), // (P)
  delta: numeric("delta").notNull(),

  // Additional info
  supplierName: text("supplier_name").notNull(),
  supplierLocation: text("supplier_location").notNull(),
  supplierOrderNumber: text("supplier_order_number").notNull(),
  fuelType: text("fuel_type").notNull(),
  temperature: numeric("temperature").notNull(),
});

export const calculationSchema = createInsertSchema(fuelCalculations)
  .extend({
    aircraftType: z.enum(["ATR", "B737"]),
    fuelType: z.enum(["JET-A1", "JP-4"]),
    time: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format"),
    leftTank: z.number().min(0),
    rightTank: z.number().min(0),
    centerTank: z.number().min(0).optional(),
    leftTankAfter: z.number().min(0),
    rightTankAfter: z.number().min(0),
    centerTankAfter: z.number().min(0).optional(),
    density: z.number().min(0.7).max(1),
    temperature: z.number().min(-50).max(50),
    registration: z.string().min(4).max(10),
    flightNumber: z.string().regex(/^ROT/, "Flight number must start with ROT"),
    fromLocation: z.string().min(3),
    toLocation: z.string().min(3),
    orderedBy: z.string().min(2),
    checkedBy: z.string().min(2),
    performedBy: z.string().min(2),
    supplierOrderNumber: z.string().min(1),
    supplierName: z.string().min(2),
    supplierLocation: z.string().min(2)
  });

export type FuelCalculation = typeof fuelCalculations.$inferSelect;
export type InsertFuelCalculation = z.infer<typeof calculationSchema>;