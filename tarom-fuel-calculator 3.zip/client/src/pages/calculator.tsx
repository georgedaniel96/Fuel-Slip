import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { calculationSchema, type InsertFuelCalculation } from "@shared/schema";
import { calculateTotals, validateDelta, distributeFuel } from "@/lib/calculations";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { useEffect } from "react";

export default function Calculator() {
  const { toast } = useToast();

  const form = useForm<InsertFuelCalculation>({
    resolver: zodResolver(calculationSchema),
    defaultValues: {
      aircraftType: "ATR",
      date: new Date(),
      time: format(new Date(), "HH:mm"),
      density: 0.8,
      temperature: 15,
      fuelType: "JET-A1"
    }
  });

  // Watch FOB Before Refueling and update RFOB when it changes
  useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      if (name === 'fobBeforeRefueling') {
        form.setValue('rfob', parseFloat(value.fobBeforeRefueling || '0'));
      }
    });
    return () => subscription.unsubscribe();
  }, [form]);

  // Add new useEffect for total requested distribution
  useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      if (name === 'totalRequested') {
        const total = parseFloat(value.totalRequested || '0');
        const { leftTank, rightTank, centerTank } = distributeFuel(total);

        form.setValue('leftTank', leftTank);
        form.setValue('rightTank', rightTank);
        form.setValue('centerTank', centerTank);
      }
    });
    return () => subscription.unsubscribe();
  }, [form]);

  // Update the useEffect hook for calculations
  useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      if (name === 'upliftedLiters' || name === 'density' || name === 'fobBeforeRefueling' ||
          name?.includes('TankAfter')) {
        // Calculate Uplift Quantity
        const upliftLiters = parseFloat(value.upliftedLiters || '0');
        const density = parseFloat(value.density || '0.8');
        const upliftQuantity = upliftLiters * density;
        const fobBeforeRefueling = parseFloat(value.fobBeforeRefueling || '0');

        // Calculate Total CFOB After Refueling
        const totalCfobAfterRefueling = fobBeforeRefueling + upliftQuantity;

        // Calculate Total After Refueling from tanks
        const totalAfterRefueling =
          parseFloat(value.leftTankAfter || '0') +
          parseFloat(value.centerTankAfter || '0') +
          parseFloat(value.rightTankAfter || '0');

        // Calculate Delta
        const delta = totalAfterRefueling - totalCfobAfterRefueling;

        form.setValue('upliftQuantity', upliftQuantity);
        form.setValue('totalCfobAfterRefueling', totalCfobAfterRefueling);
        form.setValue('delta', delta);
      }
    });
    return () => subscription.unsubscribe();
  }, [form]);

  const { mutate } = useMutation({
    mutationFn: async (data: InsertFuelCalculation) => {
      const res = await apiRequest("POST", "/api/calculations", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Fuel calculation saved successfully"
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save calculation",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (data: InsertFuelCalculation) => {
    const totals = calculateTotals({
      leftTank: data.leftTank,
      rightTank: data.rightTank,
      centerTank: data.centerTank,
      leftTankAfter: data.leftTankAfter,
      rightTankAfter: data.rightTankAfter,
      centerTankAfter: data.centerTankAfter,
      fobBeforeRefueling: data.fobBeforeRefueling,
      density: data.density,
      upliftedLiters: data.upliftedLiters,
      rfob: data.rfob,
      usedFuel: data.usedFuel
    });

    if (!validateDelta(totals.delta, data.aircraftType)) {
      toast({
        title: "Validation Error",
        description: `Delta exceeds threshold for ${data.aircraftType}. Please check drip sticks.`,
        variant: "destructive"
      });
      return;
    }

    mutate({
      ...data,
      ...totals
    });
  };

  return (
    <div className="container mx-auto py-8 relative min-h-screen">
      {/* Watermark and Download button - updated styling */}
      <div className="fixed bottom-4 right-4 flex items-center gap-4">
        <a 
          href="/download"
          className="bg-[#003875] text-white px-4 py-2 rounded-md hover:bg-[#002855] transition-colors"
          download
        >
          Download Project
        </a>
        <div className="text-gray-600 text-base font-semibold bg-white/80 px-3 py-1 rounded shadow-sm">
          Created by George Ancuta
        </div>
      </div>

      <Card>
        <CardHeader className="text-center pb-2">
          <img 
            src="/assets/tarom-logo.jpeg" 
            alt="TAROM Logo"
            className="w-64 h-auto mx-auto mb-4 object-contain"
          />
          <CardTitle className="text-2xl font-bold text-[#003875] mt-2">TAROM Fuel Calculator</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Aircraft Info */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="aircraftType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Aircraft Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select aircraft type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="ATR">ATR</SelectItem>
                          <SelectItem value="B737">Boeing 737</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="registration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Registration</FormLabel>
                      {form.watch('aircraftType') === 'B737' ? (
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select B737 registration" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="YR-BGF">YR-BGF</SelectItem>
                            <SelectItem value="YR-BGG">YR-BGG</SelectItem>
                            <SelectItem value="YR-BGI">YR-BGI</SelectItem>
                            <SelectItem value="YR-BGH">YR-BGH</SelectItem>
                            <SelectItem value="YR-BGL">YR-BGL</SelectItem>
                            <SelectItem value="YR-BGM">YR-BGM</SelectItem>
                            <SelectItem value="YR-BGJ">YR-BGJ</SelectItem>
                            <SelectItem value="YR-BGK">YR-BGK</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <FormControl>
                          <Input {...field} placeholder="YR-XXX" />
                        </FormControl>
                      )}
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="flightNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Flight Number</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="ROT123" />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              {/* Flight Info */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <FormField
                  control={form.control}
                  name="time"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Time</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="fromLocation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>From</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="OTP" />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="toLocation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>To</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="CLJ" />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              {/* Personnel */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="orderedBy"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ordered By</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="checkedBy"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Checked By</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="performedBy"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Performed By</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              {/* Requested Fuel Quantity */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Requested Fuel Quantity (kg)</h3>
                  <div className="grid grid-cols-1 gap-4">
                    {/* Add Total Requested input */}
                    <FormField
                      control={form.control}
                      name="totalRequested"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Total Requested Fuel</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              {...field}
                              onChange={e => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="leftTank"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Left Tank (max 3900kg)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              {...field}
                              onChange={e => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="centerTank"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Center Tank</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              {...field}
                              onChange={e => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="rightTank"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Right Tank (max 3900kg)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              {...field}
                              onChange={e => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    {/* Total for Requested Fuel */}
                    <div className="pt-2 border-t space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-semibold">Total Requested:</span>
                        <span className="text-lg">
                          {(form.watch('leftTank') || 0) +
                           (form.watch('centerTank') || 0) +
                           (form.watch('rightTank') || 0)} kg
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-blue-600">
                        <span className="font-semibold">REQUIRED UPLIFT (Total - RFOB):</span>
                        <span className="text-lg">
                          {((form.watch('leftTank') || 0) +
                            (form.watch('centerTank') || 0) +
                            (form.watch('rightTank') || 0)) -
                            (form.watch('rfob') || 0)} kg
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-green-600">
                        <span className="font-semibold">TO UPLIFT (LTR):</span>
                        <span className="text-lg">
                          {(((form.watch('leftTank') || 0) +
                             (form.watch('centerTank') || 0) +
                             (form.watch('rightTank') || 0)) -
                             (form.watch('rfob') || 0)) /
                             (form.watch('density') || 1)} L
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* After Refueling */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">After Refueling (MLI/Drip sticks)</h3>
                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="leftTankAfter"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Left Tank</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(parseFloat(e.target.value))} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="centerTankAfter"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Center Tank</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(parseFloat(e.target.value))} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="rightTankAfter"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Right Tank</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(parseFloat(e.target.value))} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    {/* Total for After Refueling */}
                    <div className="pt-2 border-t">
                      <div className="flex justify-between items-center">
                        <span className="font-semibold">Total After Refueling:</span>
                        <span className="text-lg">
                          {(form.watch('leftTankAfter') || 0) +
                           (form.watch('centerTankAfter') || 0) +
                           (form.watch('rightTankAfter') || 0)} kg
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Calculations */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Calculations</h3>
                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="fobBeforeRefueling"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>FOB Before Refueling (C)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(parseFloat(e.target.value))} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="density"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Density (E)</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.001" {...field} onChange={e => field.onChange(parseFloat(e.target.value))} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    {/* Uplifted Liters field */}
                    <FormField
                      control={form.control}
                      name="upliftedLiters"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Uplifted Liters (H)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              {...field}
                              onChange={e => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    {/* Uplift Quantity field */}
                    <FormField
                      control={form.control}
                      name="upliftQuantity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Uplift Quantity (J)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} disabled />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="totalCfobAfterRefueling"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Total CFOB After Refueling (FOB + Uplift)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} disabled />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="rfob"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>RFOB (K)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              {...field}
                              onChange={e => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="usedFuel"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Used Fuel - APU/Hotel Mode (M)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(parseFloat(e.target.value))} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    {/* Delta field moved to the end of calculations */}
                    <FormField
                      control={form.control}
                      name="delta"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex justify-between items-center">
                            <span>Delta (Total After - Total CFOB)</span>
                            <span className={`text-sm ${Math.abs(field.value || 0) > (form.watch('aircraftType') === 'ATR' ? 150 : 200) ? 'text-red-500' : 'text-green-500'}`}>
                              {field.value ? `${field.value.toFixed(2)} kg` : '0.00 kg'}
                            </span>
                          </FormLabel>
                          <FormControl>
                            <Input type="number" {...field} disabled />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Additional Info */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Additional Information</h3>
                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="supplierName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Supplier Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="supplierLocation"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Supplier Location</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="supplierOrderNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Supplier Order Number</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="fuelType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Fuel Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select fuel type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="JET-A1">JET-A1</SelectItem>
                              <SelectItem value="JP-4">JP-4</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="temperature"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ambient Temperature (°C)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(parseFloat(e.target.value))} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </div>

              <Button type="submit" className="w-full">Calculate and Save</Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}