import { NextRequest, NextResponse } from 'next/server';
import { calculationSchema } from "@shared/schema";
import { db } from "../server/db";
import { fuelCalculations } from "@shared/schema";

export const config = {
  runtime: 'edge',
};

export default async function handler(req: NextRequest) {
  if (req.method === 'POST') {
    try {
      const body = await req.json();
      const calculation = calculationSchema.parse(body);
      const [result] = await db
        .insert(fuelCalculations)
        .values(calculation)
        .returning();
      return NextResponse.json(result);
    } catch (error) {
      return NextResponse.json({ error: "Invalid calculation data" }, { status: 400 });
    }
  } else if (req.method === 'GET') {
    const calculations = await db
      .select()
      .from(fuelCalculations)
      .orderBy(fuelCalculations.date);
    return NextResponse.json(calculations);
  }

  return NextResponse.json({ error: "Method not allowed" }, { status: 405 });
}