import { fuelCalculations, type FuelCalculation, type InsertFuelCalculation } from "@shared/schema";
import { db } from "./db";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  createCalculation(calculation: InsertFuelCalculation): Promise<FuelCalculation>;
  getCalculations(): Promise<FuelCalculation[]>;
}

export class DatabaseStorage implements IStorage {
  async createCalculation(calculation: InsertFuelCalculation): Promise<FuelCalculation> {
    const [result] = await db
      .insert(fuelCalculations)
      .values(calculation)
      .returning();
    return result;
  }

  async getCalculations(): Promise<FuelCalculation[]> {
    return await db
      .select()
      .from(fuelCalculations)
      .orderBy(fuelCalculations.date);
  }
}

export const storage = new DatabaseStorage();