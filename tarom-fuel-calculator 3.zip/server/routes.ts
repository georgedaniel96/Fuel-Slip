import type { Express } from "express";
import { createServer, type Server } from "http";
import { calculationSchema } from "@shared/schema";
import { storage } from "./storage";
import path from "path";

export function registerRoutes(app: Express): Server {
  app.post("/api/calculations", async (req, res) => {
    try {
      const calculation = calculationSchema.parse(req.body);
      const result = await storage.createCalculation(calculation);
      res.json(result);
    } catch (error) {
      res.status(400).json({ error: "Invalid calculation data" });
    }
  });

  app.get("/api/calculations", async (_req, res) => {
    const calculations = await storage.getCalculations();
    res.json(calculations);
  });

  // Add download route
  app.get("/download", (_req, res) => {
    const file = path.resolve(process.cwd(), 'project.zip');
    res.download(file, 'tarom-fuel-calculator.zip');
  });

  const httpServer = createServer(app);
  return httpServer;
}