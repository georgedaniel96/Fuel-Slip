git init
   git add .
   git commit -m "Initial commit"
   git remote add origin your-github-repo-url
   git push -u origin main
   ```

2. Set up Vercel:
   - Go to [Vercel](https://vercel.com)
   - Sign in with GitHub
   - Click "New Project"
   - Import your repository
   - Configure project:
     - Framework Preset: Vite
     - Build Command: `npm run build`
     - Output Directory: `dist/public`
     - Install Command: `npm install`

3. Environment Variables:
   - Add the following in Vercel project settings:
     ```
     DATABASE_URL=your_postgresql_connection_string
     ```
   - Make sure to use a PostgreSQL database that's compatible with Vercel
   - For Neon database users, use the pooled connection string

4. Deploy:
   - Click "Deploy"
   - Vercel will automatically build and deploy your application
   - Your app will be available at `https://your-project.vercel.app`

### Database Setup

1. Create a new database in your chosen provider (Neon/Supabase/Vercel Postgres)

2. Get your database connection string in this format:
   ```
   postgresql://user:password@host:port/database
   ```

3. Add the connection string to Vercel environment variables

4. The database schema will be automatically created on first deployment

## Local Development

1. Clone the repository:
   ```bash
   git clone your-github-repo-url
   cd tarom-fuel-calculator
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up environment variables:
   Create a `.env` file:
   ```
   DATABASE_URL=your_database_url_here
   ```

4. Run the development server:
   ```bash
   npm run dev