export function calculateDelta(readings: number[], aircraftType: "ATR" | "B737"): number {
  const total = readings.reduce((sum, reading) => sum + reading, 0);
  const threshold = aircraftType === "ATR" ? 150 : 200; //Updated ATR threshold to 150
  return Math.abs(total) > threshold ? total : 0;
}

export function calculateTotalQuantity(readings: number[], density: number): number {
  return readings.reduce((sum, reading) => sum + reading * density, 0);
}

export function validateReadings(readings: number[], aircraftType: "ATR" | "B737"): boolean {
  const total = readings.reduce((sum, reading) => sum + reading, 0);
  const threshold = aircraftType === "ATR" ? 150 : 200; //Updated ATR threshold to 150
  return Math.abs(total) <= threshold;
}

export function distributeFuel(totalRequested: number): {
  leftTank: number;
  rightTank: number;
  centerTank: number;
} {
  const maxTankCapacity = 3900;

  // Distribute equally to left and right tanks first
  let leftTank = Math.min(maxTankCapacity, totalRequested / 2);
  let rightTank = Math.min(maxTankCapacity, totalRequested / 2);

  // Adjust if tanks are maxed out
  if (leftTank === maxTankCapacity) {
    rightTank = Math.min(maxTankCapacity, totalRequested - maxTankCapacity);
  } else if (rightTank === maxTankCapacity) {
    leftTank = Math.min(maxTankCapacity, totalRequested - maxTankCapacity);
  }

  // Any remaining fuel goes to center tank
  const centerTank = Math.max(0, totalRequested - leftTank - rightTank);

  return {
    leftTank,
    rightTank,
    centerTank
  };
}

export function calculateTotals(data: {
  leftTank: number;
  rightTank: number;
  centerTank?: number;
  leftTankAfter: number;
  rightTankAfter: number;
  centerTankAfter?: number;
  fobBeforeRefueling: number;
  density: number;
  upliftedLiters: number;
  rfob: number;
  usedFuel: number;
}){
  // Calculate Total (A) - Total Requested
  const totalRequested = data.leftTank + data.rightTank + (data.centerTank || 0);

  // Calculate Total (B) - Total Indicators
  const totalIndicators = data.leftTankAfter + data.rightTankAfter + (data.centerTankAfter || 0);

  // Calculate (D) - Required Uplift
  const requiredUplift = totalRequested - data.fobBeforeRefueling;

  // Calculate (F) - To Uplift
  const toUplift = requiredUplift / data.density;

  // Calculate (J) - Uplift Quantity
  const upliftQuantity = data.upliftedLiters * data.density;

  // Calculate (L) - Total CFOB after refueling
  const totalCfobAfterRefueling = upliftQuantity + data.rfob;

  // Calculate (N) - CFOB after Refueling
  const cfobAfterRefueling = totalCfobAfterRefueling - data.usedFuel;

  // Calculate delta between N and P (totalIndicators)
  const delta = cfobAfterRefueling - totalIndicators;

  return {
    totalRequested,
    totalIndicators,
    requiredUplift,
    toUplift,
    upliftQuantity,
    totalCfobAfterRefueling,
    cfobAfterRefueling,
    delta
  };
}

export function validateDelta(delta: number, aircraftType: "ATR" | "B737"): boolean {
  const threshold = aircraftType === "ATR" ? 150 : 200;
  return Math.abs(delta) <= threshold;
}